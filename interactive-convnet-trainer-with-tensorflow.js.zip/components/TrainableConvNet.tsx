
import React, { useState, useEffect, useCallback } from 'react';
import type { LayerConfig, TrainingDataPoint, PredictionState } from '../types';
import { LayerType, ActivationFunction, PoolingType } from '../types';
// import { imageToGrid, drawGridToCanvas } from '../utils/cnnUtils'; // drawGridToCanvas not used here

import { ArchitectureDefinition } from './ArchitectureDefinition';
import { DataCollection } from './DataCollection';
import { TrainingControls } from './TrainingControls';
import { PredictionDisplay } from './PredictionDisplay';
import { PipelineVisualization } from './PipelineVisualization';
import { useTFModel, ModelStatus as TFModelStatus } from '../hooks/useTFModel'; // The new TensorFlow.js hook

const LOCAL_STORAGE_KEY_TRAINING_DATA = 'cnnTrainerTrainingDataTF'; // Changed key for TF version

// Define the expected status type for TrainingControls for clarity
type TrainingControlsStatus = 'collecting' | 'training' | 'success' | 'architecture-changed' | 'error';

interface AppSessionData {
    layers: LayerConfig[];
    trainingData: TrainingDataPoint[];
}

export const TrainableConvNet: React.FC = () => {
    const [layers, setLayers] = useState<LayerConfig[]>([
        { id: Date.now() + 1, type: LayerType.Conv, filterSize: 3, numFilters: 8, activation: ActivationFunction.ReLU },
        { id: Date.now() + 2, type: LayerType.Pool, poolSize: 2, poolingType: PoolingType.Max },
        { id: Date.now() + 3, type: LayerType.Conv, filterSize: 3, numFilters: 16, activation: ActivationFunction.ReLU },
        { id: Date.now() + 4, type: LayerType.Pool, poolSize: 2, poolingType: PoolingType.Max },
        // Flatten and Dense layers will be implicitly added by useTFModel if not present before final output,
        // or user can add them explicitly.
        // { id: Date.now() + 5, type: LayerType.Flatten },
        // { id: Date.now() + 6, type: LayerType.Dense, units: 1, activation: ActivationFunction.Sigmoid }
    ]);
    const [trainingData, setTrainingData] = useState<TrainingDataPoint[]>(() => {
        try {
            const savedData = localStorage.getItem(LOCAL_STORAGE_KEY_TRAINING_DATA);
            return savedData ? JSON.parse(savedData) : [];
        } catch (error) {
            console.error("Failed to load training data from localStorage:", error);
            return [];
        }
    });
    const [numEpochs, setNumEpochs] = useState<number>(10); // Reduced default for faster TF.js iteration
    const [learningRate, setLearningRate] = useState<number>(0.001); // Common default for Adam
    const [batchSize, setBatchSize] = useState<number>(8);
    
    const [activeVizChannel, setActiveVizChannel] = useState<{[layerId: string]: number}>({});
    
    // Augmentation states
    const [augmentFlip, setAugmentFlip] = useState<boolean>(false);
    const [augmentTranslate, setAugmentTranslate] = useState<boolean>(false);


    const {
        model, // This is now a tf.Sequential or null
        status: tfStatus, // Renamed to avoid conflict and to clarify its origin
        prediction,
        epochsRun,
        lossHistory,
        liveLayerOutputs,
        fcWeightsViz,
        initializeModel, // To explicitly build/compile
        runPrediction,
        startTrainingLogic,
        resetModelTrainingState,
    } = useTFModel({
        initialLayers: layers,
        learningRate,
        // numEpochs and batchSize are passed directly to startTrainingLogic
    });

    useEffect(() => {
        try {
            localStorage.setItem(LOCAL_STORAGE_KEY_TRAINING_DATA, JSON.stringify(trainingData));
        } catch (error) {
            console.error("Failed to save training data to localStorage:", error);
        }
    }, [trainingData]);

    const handleAddLayer = (layerTypeToAdd: LayerType) => {
        let newLayer: LayerConfig;
        const newId = Date.now(); 
        switch (layerTypeToAdd) {
            case LayerType.Conv:
                newLayer = { id: newId, type: LayerType.Conv, filterSize: 3, numFilters: 8, activation: ActivationFunction.ReLU };
                break;
            case LayerType.Pool:
                newLayer = { id: newId, type: LayerType.Pool, poolSize: 2, poolingType: PoolingType.Max };
                break;
            case LayerType.Activation:
                newLayer = { id: newId, type: LayerType.Activation, func: ActivationFunction.ReLU };
                break;
            case LayerType.Dropout:
                newLayer = { id: newId, type: LayerType.Dropout, rate: 0.25 };
                break;
            case LayerType.Flatten:
                newLayer = { id: newId, type: LayerType.Flatten };
                break;
            case LayerType.Dense:
                newLayer = { id: newId, type: LayerType.Dense, units: 10, activation: ActivationFunction.ReLU };
                break;
            default:
                console.error("Unhandled layer type:", layerTypeToAdd); return;
        }
        setLayers(prevLayers => [...prevLayers, newLayer]);
    };

    const handleRemoveLayer = (id: number | string) => {
        setLayers(prev => prev.filter(layer => layer.id !== id));
    };

    const handleUpdateLayer = (id: number | string, newConfig: Partial<LayerConfig>) => {
        setLayers(prev => prev.map(layer => layer.id === id ? { ...layer, ...newConfig } as LayerConfig : layer));
    };

    const handleAddTrainingData = (grid: number[][], label: 0 | 1) => {
        setTrainingData(prev => [...prev, { id: Date.now(), grid, label }]);
    };

    const handleRemoveTrainingDataPoint = (id: number | string) => {
        setTrainingData(prev => prev.filter(dataPoint => dataPoint.id !== id));
    };
    
    const predictFromDataCollectionCanvas = useCallback(async (grid: number[][]) => {
        await runPrediction(grid);
    }, [runPrediction]);


    const handleStartTraining = async () => {
        if (trainingData.length === 0 ) {
            alert("Please add training samples."); return;
        }
         if (trainingData.length < batchSize ) {
            alert(`Batch size (${batchSize}) cannot be greater than the number of training samples (${trainingData.length}). Please reduce batch size or add more samples.`); return;
        }
        if (batchSize <= 0) {
            alert("Batch size must be greater than 0."); return;
        }
        if (!trainingData.some(d=>d.label === 0) || !trainingData.some(d=>d.label === 1)){
             alert("Please add training examples for both class '0' and class '1'."); return;
        }
        await startTrainingLogic(trainingData, numEpochs, batchSize);
    };

    const handleClearTrainingData = () => {
        setTrainingData([]);
        setActiveVizChannel({});
    };

    const handleFullReset = useCallback(async () => {
        setTrainingData([]);
        await resetModelTrainingState(); 
        setLayers([ 
            { id: Date.now() + 1, type: LayerType.Conv, filterSize: 3, numFilters: 8, activation: ActivationFunction.ReLU },
            { id: Date.now() + 2, type: LayerType.Pool, poolSize: 2, poolingType: PoolingType.Max },
        ]);
        setActiveVizChannel({});
        // Prediction on empty grid will be triggered by DataCollection's clear via predictFromDataCollectionCanvas
    }, [resetModelTrainingState]);
    
    // Effect for auto-inference after training success (or on ready state)
     useEffect(() => {
        if ((tfStatus === 'success' || tfStatus === 'ready') && trainingData.length > 0) {
            const randomIndex = Math.floor(Math.random() * trainingData.length);
            const randomSampleGrid = trainingData[randomIndex].grid;
            runPrediction(randomSampleGrid);
        } else if ((tfStatus === 'success' || tfStatus === 'ready') && trainingData.length === 0) {
            // If model is ready but no data, predict on an empty grid (e.g. from data collection canvas)
            // This is typically handled by the onDrawEnd of useDrawingCanvas in DataCollection
        }
    }, [tfStatus, trainingData, runPrediction]);


    // Initial model initialization and prediction on mount/architecture change
    useEffect(() => {
        if (tfStatus === 'uninitialized' || tfStatus === 'architecture-changed') {
            initializeModel().then(m => {
                if (m) { // If model is built successfully
                     // Predict on an empty grid (will be triggered by DataCollection's initial clear)
                }
            });
        }
    }, [tfStatus, initializeModel, predictFromDataCollectionCanvas]);


    const maxBatchSize = trainingData.length > 0 ? trainingData.length : 32; // Batch size can be up to num samples

    const handleChannelCycle = (layerId: string, numTotalChannels: number) => {
        setActiveVizChannel(prev => {
            const current = prev[layerId] || 0;
            return { ...prev, [layerId]: (current + 1) % numTotalChannels };
        });
    };

    const getTrainingControlsStatus = (s: TFModelStatus): TrainingControlsStatus => {
        if (s === 'training' || s === 'success' || s === 'architecture-changed' || s === 'error') {
            return s;
        }
        // Maps uninitialized, initializing, building, compiling, ready to collecting
        return 'collecting';
    };
    const mappedStatusForTrainingControls = getTrainingControlsStatus(tfStatus);

    const handleSaveSession = () => {
        const sessionData: AppSessionData = {
            layers: layers,
            trainingData: trainingData,
        };
        const jsonString = JSON.stringify(sessionData, null, 2);
        const blob = new Blob([jsonString], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'cnn_session_data.json';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        alert("Session data saved successfully!");
    };

    const handleLoadSession = () => {
        const fileInput = document.createElement('input');
        fileInput.type = 'file';
        fileInput.accept = '.json';
        fileInput.onchange = (e) => {
            const target = e.target as HTMLInputElement;
            if (target.files && target.files[0]) {
                const file = target.files[0];
                const reader = new FileReader();
                reader.onload = (event) => {
                    try {
                        const result = event.target?.result;
                        if (typeof result === 'string') {
                            const parsedData: AppSessionData = JSON.parse(result);
                            // Basic validation
                            if (parsedData && Array.isArray(parsedData.layers) && Array.isArray(parsedData.trainingData)) {
                                // Further validation could be added here (e.g., check structure of layer objects, training data points)
                                setLayers(parsedData.layers);
                                setTrainingData(parsedData.trainingData);
                                // Model will re-initialize due to layers change via useEffect in useTFModel
                                alert("Session data loaded successfully! Model will re-initialize.");
                            } else {
                                throw new Error("Invalid session file structure.");
                            }
                        } else {
                             throw new Error("Failed to read file content as string.");
                        }
                    } catch (error: any) {
                        console.error("Error loading session data:", error);
                        alert(`Failed to load session data: ${error.message || 'Unknown error'}`);
                    }
                };
                reader.onerror = () => {
                    alert("Error reading file.");
                };
                reader.readAsText(file);
            }
        };
        fileInput.click();
    };
    
    return (
        <div className="space-y-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="bg-gray-800 p-6 rounded-lg shadow-lg space-y-6">
                    <ArchitectureDefinition
                        layers={layers}
                        updateLayer={handleUpdateLayer}
                        removeLayer={handleRemoveLayer}
                        addLayer={handleAddLayer}
                    />
                    <DataCollection 
                        onAddData={handleAddTrainingData} 
                        predictFromCanvas={predictFromDataCollectionCanvas}
                        augmentFlip={augmentFlip}
                        onAugmentFlipChange={setAugmentFlip}
                        augmentTranslate={augmentTranslate}
                        onAugmentTranslateChange={setAugmentTranslate}
                    />
                </div>
                <div className="bg-gray-800 p-6 rounded-lg shadow-lg">
                    <TrainingControls
                        trainingData={trainingData}
                        onClearTrainingData={handleClearTrainingData}
                        onRemoveTrainingDataPoint={handleRemoveTrainingDataPoint}
                        numEpochs={numEpochs}
                        onNumEpochsChange={setNumEpochs}
                        learningRate={learningRate}
                        onLearningRateChange={setLearningRate}
                        batchSize={batchSize}
                        onBatchSizeChange={(val) => setBatchSize(Math.max(1, val))} 
                        maxBatchSize={maxBatchSize}
                        onStartTraining={handleStartTraining}
                        onResetAll={handleFullReset}
                        status={mappedStatusForTrainingControls}
                        epochsRun={epochsRun}
                        lossHistory={lossHistory}
                        onSaveSession={handleSaveSession} // Pass new handler
                        onLoadSession={handleLoadSession} // Pass new handler
                    />
                     <PredictionDisplay prediction={prediction} modelReady={!!model && (tfStatus === 'ready' || tfStatus === 'success' || tfStatus === 'training')} />
                </div>
            </div>
            
            <PipelineVisualization
                liveLayerOutputs={liveLayerOutputs}
                fcWeightsViz={fcWeightsViz}
                prediction={prediction}
                activeVizChannel={activeVizChannel}
                onChannelCycle={handleChannelCycle}
                status={tfStatus}
            />
        </div>
    );
};
