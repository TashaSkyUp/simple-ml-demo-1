import React from 'react';
import type { LayerConfig, ConvLayerConfig, PoolLayerConfig, DropoutLayerConfig, ActivationLayerConfig, DenseLayerConfig, FlattenLayerConfig } from '../types';
import { LayerType, ActivationFunction, PoolingType } from '../types';

interface ArchitectureDefinitionProps {
    layers: LayerConfig[];
    updateLayer: (id: string | number, newConfig: Partial<LayerConfig>) => void;
    removeLayer: (id: string | number) => void;
    addLayer: (type: LayerType) => void;
}

export const ArchitectureDefinition: React.FC<ArchitectureDefinitionProps> = ({
    layers,
    updateLayer,
    removeLayer,
    addLayer,
}) => {
    const handleNumericInput = (value: string, defaultValue: number = 1, min: number = 1, max: number = Infinity): number => {
        const parsed = parseInt(value);
        if (isNaN(parsed)) {
            return defaultValue;
        }
        return Math.max(min, Math.min(max, parsed));
    };
     const handleFloatInput = (value: string, defaultValue: number = 0.1, min: number = 0, max: number = 1): number => {
        const parsed = parseFloat(value);
        if (isNaN(parsed)) {
            return defaultValue;
        }
        return Math.max(min, Math.min(max, parsed));
    };


    return (
        <div>
            <h2 className="text-2xl font-bold mb-4 text-cyan-400">1. Define Architecture</h2>
            <div className="space-y-3 bg-gray-900/50 p-3 rounded-lg max-h-96 overflow-y-auto">
                {layers.map((layer, index) => (
                    <div key={layer.id} className="bg-gray-700 p-3 rounded-md">
                        <div className="flex justify-between items-center mb-2">
                            <p className="font-bold text-cyan-400">Layer {index + 1}: {layer.type.charAt(0).toUpperCase() + layer.type.slice(1)}</p>
                            <button 
                                onClick={() => removeLayer(layer.id)} 
                                className="text-red-400 hover:text-red-300 font-bold p-1 leading-none rounded-full focus:outline-none focus:ring-2 focus:ring-red-500"
                                aria-label={`Remove layer ${index + 1}`}
                            >
                                &times;
                            </button>
                        </div>
                        {layer.type === LayerType.Conv && (<>
                            <div className="grid grid-cols-2 gap-x-4 gap-y-2">
                                <div>
                                    <label htmlFor={`conv-filtersize-${layer.id}`} className="text-sm text-gray-400 block">Filter Size</label>
                                    <select 
                                        id={`conv-filtersize-${layer.id}`}
                                        value={(layer as ConvLayerConfig).filterSize} 
                                        onChange={(e) => updateLayer(layer.id, { filterSize: parseInt(e.target.value) as 3 | 5 })} 
                                        className="w-full bg-gray-800 text-white p-2 rounded-md border border-gray-600 mt-1"
                                    >
                                        <option value="3">3x3</option>
                                        <option value="5">5x5</option>
                                    </select>
                                </div>
                                <div>
                                    <label htmlFor={`conv-numfilters-${layer.id}`} className="text-sm text-gray-400 block">Num Filters</label>
                                    <input 
                                        id={`conv-numfilters-${layer.id}`}
                                        type="number" min="1" max="64" step="1" 
                                        value={(layer as ConvLayerConfig).numFilters} 
                                        onChange={(e) => updateLayer(layer.id, { numFilters: handleNumericInput(e.target.value, 1, 1, 64) })} 
                                        className="w-full bg-gray-800 text-white p-2 rounded-md border border-gray-600 mt-1" 
                                    />
                                </div>
                                <div className="col-span-2">
                                    <label htmlFor={`conv-activation-${layer.id}`} className="text-sm text-gray-400 block">Activation</label>
                                    <select 
                                        id={`conv-activation-${layer.id}`}
                                        value={(layer as ConvLayerConfig).activation || ActivationFunction.ReLU} 
                                        onChange={(e) => updateLayer(layer.id, { activation: e.target.value as ActivationFunction })} 
                                        className="w-full bg-gray-800 text-white p-2 rounded-md border border-gray-600 mt-1"
                                    >
                                        {Object.values(ActivationFunction).map(funcName => (
                                           <option key={funcName} value={funcName}>{funcName.charAt(0).toUpperCase() + funcName.slice(1)}</option>
                                        ))}
                                    </select>
                                </div>
                            </div>
                        </>)}
                        {layer.type === LayerType.Pool && (<>
                             <div className="grid grid-cols-2 gap-x-4 gap-y-2">
                                <div>
                                    <label htmlFor={`pool-size-${layer.id}`} className="text-sm text-gray-400 block">Pool Size: {(layer as PoolLayerConfig).poolSize}x{(layer as PoolLayerConfig).poolSize}</label>
                                    <input 
                                        id={`pool-size-${layer.id}`}
                                        type="range" min="2" max="4" step="1" 
                                        value={(layer as PoolLayerConfig).poolSize} 
                                        onChange={(e) => updateLayer(layer.id, { poolSize: parseInt(e.target.value) })} 
                                        className="w-full h-2 bg-gray-600 rounded-lg appearance-none cursor-pointer mt-1 accent-cyan-500" 
                                    />
                                </div>
                                <div>
                                    <label htmlFor={`pool-type-${layer.id}`} className="text-sm text-gray-400 block">Pooling Type</label>
                                    <select 
                                        id={`pool-type-${layer.id}`}
                                        value={(layer as PoolLayerConfig).poolingType} 
                                        onChange={(e) => updateLayer(layer.id, { poolingType: e.target.value as PoolingType })} 
                                        className="w-full bg-gray-800 text-white p-2 rounded-md border border-gray-600 mt-1"
                                    >
                                        {Object.values(PoolingType).map(poolTypeName => (
                                        <option key={poolTypeName} value={poolTypeName}>{poolTypeName.charAt(0).toUpperCase() + poolTypeName.slice(1)}</option>
                                        ))}
                                    </select>
                                </div>
                            </div>
                        </>)}
                        {layer.type === LayerType.Dropout && (<>
                            <label htmlFor={`dropout-rate-${layer.id}`} className="text-sm text-gray-400 block">Dropout Rate: {Math.round((layer as DropoutLayerConfig).rate * 100)}%</label>
                            <input 
                                id={`dropout-rate-${layer.id}`}
                                type="range" min="0.05" max="0.5" step="0.01" 
                                value={(layer as DropoutLayerConfig).rate} 
                                onChange={(e) => updateLayer(layer.id, { rate: parseFloat(e.target.value) })} 
                                className="w-full h-2 bg-gray-600 rounded-lg appearance-none cursor-pointer mt-1 accent-cyan-500" 
                            />
                        </>)}
                        {layer.type === LayerType.Activation && (<>
                            <label htmlFor={`activation-func-${layer.id}`} className="text-sm text-gray-400 block">Function</label>
                            <select 
                                id={`activation-func-${layer.id}`}
                                value={(layer as ActivationLayerConfig).func} 
                                onChange={(e) => updateLayer(layer.id, { func: e.target.value as ActivationFunction })} 
                                className="w-full bg-gray-800 text-white p-2 rounded-md border border-gray-600 mt-1"
                            >
                                {Object.values(ActivationFunction).map(funcName => (
                                   <option key={funcName} value={funcName}>{funcName.charAt(0).toUpperCase() + funcName.slice(1)}</option>
                                ))}
                            </select>
                        </>)}
                        {layer.type === LayerType.Dense && (<>
                            <div className="grid grid-cols-2 gap-x-4 gap-y-2">
                                <div>
                                    <label htmlFor={`dense-units-${layer.id}`} className="text-sm text-gray-400 block">Units</label>
                                    <input 
                                        id={`dense-units-${layer.id}`}
                                        type="number" min="1" max="128" step="1" 
                                        value={(layer as DenseLayerConfig).units} 
                                        onChange={(e) => updateLayer(layer.id, { units: handleNumericInput(e.target.value, 1, 1, 128) })} 
                                        className="w-full bg-gray-800 text-white p-2 rounded-md border border-gray-600 mt-1" 
                                    />
                                </div>
                                <div>
                                    <label htmlFor={`dense-activation-${layer.id}`} className="text-sm text-gray-400 block">Activation</label>
                                    <select 
                                        id={`dense-activation-${layer.id}`}
                                        value={(layer as DenseLayerConfig).activation} 
                                        onChange={(e) => updateLayer(layer.id, { activation: e.target.value as ActivationFunction })} 
                                        className="w-full bg-gray-800 text-white p-2 rounded-md border border-gray-600 mt-1"
                                    >
                                        {Object.values(ActivationFunction).map(funcName => (
                                        <option key={funcName} value={funcName}>{funcName.charAt(0).toUpperCase() + funcName.slice(1)}</option>
                                        ))}
                                    </select>
                                </div>
                            </div>
                        </>)}
                        {layer.type === LayerType.Flatten && (<>
                            <p className="text-sm text-gray-400 italic">Flattens input. No configurable parameters.</p>
                        </>)}
                    </div>
                ))}
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2 pt-2">
                    <button onClick={() => addLayer(LayerType.Conv)} className="p-2 rounded-md transition-colors bg-cyan-700 hover:bg-cyan-600 focus:outline-none focus:ring-2 focus:ring-cyan-500 text-sm">(+) Conv</button>
                    <button onClick={() => addLayer(LayerType.Pool)} className="p-2 rounded-md transition-colors bg-sky-700 hover:bg-sky-600 focus:outline-none focus:ring-2 focus:ring-sky-500 text-sm">(+) Pool</button>
                    <button onClick={() => addLayer(LayerType.Activation)} className="p-2 rounded-md transition-colors bg-green-700 hover:bg-green-600 focus:outline-none focus:ring-2 focus:ring-green-500 text-sm">(+) Activation</button>
                    <button onClick={() => addLayer(LayerType.Dropout)} className="p-2 rounded-md transition-colors bg-purple-700 hover:bg-purple-600 focus:outline-none focus:ring-2 focus:ring-purple-500 text-sm">(+) Dropout</button>
                    <button onClick={() => addLayer(LayerType.Flatten)} className="p-2 rounded-md transition-colors bg-indigo-700 hover:bg-indigo-600 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm">(+) Flatten</button>
                    <button onClick={() => addLayer(LayerType.Dense)} className="p-2 rounded-md transition-colors bg-pink-700 hover:bg-pink-600 focus:outline-none focus:ring-2 focus:ring-pink-500 text-sm">(+) Dense</button>
                </div>
            </div>
        </div>
    );
};